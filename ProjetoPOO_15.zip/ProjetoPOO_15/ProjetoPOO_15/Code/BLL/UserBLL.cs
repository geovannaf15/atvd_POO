﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjetoPOO_15.Code.DAL;
using ProjetoPOO_15.Code.DTO;
using System.Data;

namespace ProjetoPOO_15.Code.BLL
{
    class UserBLL
    {
        Conexao conect = new Conexao();
        string tabela = "user";

        public void Insert(UserDTO us)
        {
            string insert = $"insert into {tabela} values(null, '{us.Name}', '{us.Cell}', '{us.Rua}', '{us.Number}', '{us.Bairro}', '{us.City}', '{us.State}', '{us.Country}', '{us.Cpf}', '{us.Rg}', '{us.Birty}', '{us.Email}', '{us.Password}')";
            conect.Executar(insert);
        }

        public void Update(UserDTO us)
        {
            string update = $@"update {tabela} set nome = '{us.Name}',
                                telefone ='{us.Cell}',
                                rua ='{us.Rua}',
                                numero ='{us.Number}',
                                bairro ='{us.Bairro}',
                                cidade ='{us.City}',
                                estado ='{us.State}',
                                pais ='{us.Country}',
                                cpf ='{us.Cpf}',
                                rg ='{us.Rg}',
                                nascimento ='{us.Birty}',
                                email ='{us.Email}',
                                senha ='{us.Password}' where id ='{us.Id}';";
            conect.Executar(update);
        }

        public void Delete(UserDTO us)
        {
            string delete = $"delete from {tabela} where id = {us.Id}";
            conect.Executar(delete);
        }

        public DataTable Read()
        {
            string listar = $"select * from {tabela} order by id";
            return conect.Consultar(listar);
        }

        public bool Login(UserDTO us)
        {
            string sql = $"select * from {tabela} where email ='{us.Email}' and senha ='{us.Password}' and cpf ='{us.Cpf}'";
            DataTable dt = conect.Consultar(sql);

            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }
    }
}
