﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjetoPOO_15.Code.DAL;
using ProjetoPOO_15.Code.DTO;
using System.Data;

namespace ProjetoPOO_15.Code.BLL
{
    class DadosBLL
    {
        Conexao conect = new Conexao();
        string tabela = "data";

        public void Insert(DadosDTO da)
        {
            string insert = $"insert into {tabela} values(null, '{da.Ggf}', '{da.G07}', '{da.F05}')";
            conect.Executar(insert);
        }

        public void Update(DadosDTO da)
        {
            string update = $@"update {tabela} set ggf = '{da.Ggf}',
                                g07 ='{da.G07}',
                                f05 ='{da.F05}' where id ='{da.Id}';";
            conect.Executar(update);
        }

        public void Delete(DadosDTO da)
        {
            string delete = $"delete from {tabela} where id = {da.Id}";
            conect.Executar(delete);
        }

        public DataTable Read()
        {
            string read = $"select * from {tabela} order by id";
            return conect.Consultar(read);
        }
    }
}