﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoPOO_15.Code.DTO
{
    class UserDTO
    {
        private int _id;
        private string _name;
        private string _cell;
        private string _rua;
        private string _number;
        private string bairro;
        private string _city;
        private string _state;
        private string _country;
        private string _cpf;
        private string _rg;
        private string _birty;
        private string _email;
        private string _password;

        public int Id { get => _id; set => _id = value; }
        public string Name { get => _name; set => _name = value; }
        public string Cell { get => _cell; set => _cell = value; }
        public string Rua { get => _rua; set => _rua = value; }
        public string Number { get => _number; set => _number = value; }
        public string Bairro { get => bairro; set => bairro = value; }
        public string City { get => _city; set => _city = value; }
        public string State { get => _state; set => _state = value; }
        public string Country { get => _country; set => _country = value; }
        public string Cpf { get => _cpf; set => _cpf = value; }
        public string Rg { get => _rg; set => _rg = value; }
        public string Birty { get => _birty; set => _birty = value; }
        public string Email { get => _email; set => _email = value; }
        public string Password { get => _password; set => _password = value; }
    }
}
