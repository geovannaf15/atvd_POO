﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoPOO_15.Code.DTO
{
    class DadosDTO
    {
        private int _id;
        private string _ggf;
        private string _g07;
        private string _f05;

        public int Id { get => _id; set => _id = value; }
        public string Ggf { get => _ggf; set => _ggf = value; }
        public string G07 { get => _g07; set => _g07 = value; }
        public string F05 { get => _f05; set => _f05 = value; }
    }
}
