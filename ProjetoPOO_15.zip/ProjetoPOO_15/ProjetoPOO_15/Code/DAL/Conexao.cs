﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ProjetoPOO_15.Code.DAL
{
    class Conexao
    {
        MySqlConnection conect;

        public void Conectar()
        {
            try
            {
                string conn = "Persist Security Info = false; " +
                    "server = localhost; " +
                    "database = geovannaPOO; " +
                    "uid = root; pwd=";

                conect = new MySqlConnection(conn);
                conect.Open();
            }
            catch (MySqlException ex)
            {
                throw new Exception("Não foi possível conectar ao banco de dados.\n" + ex.Message);
            }
        }

        public void Executar(string sql)
        {
            Conectar();
            MySqlCommand comando = new MySqlCommand(sql, conect);
            comando.ExecuteNonQuery();

        }

        public DataTable Consultar(string sql)
        {
            Conectar();
            MySqlDataAdapter dados = new MySqlDataAdapter(sql, conect);
            DataTable dt = new DataTable();
            dados.Fill(dt);
            return dt;
        }
    }
}
