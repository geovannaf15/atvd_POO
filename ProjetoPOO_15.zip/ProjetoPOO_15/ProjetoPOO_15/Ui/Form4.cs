﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjetoPOO_15.Code.BLL;
using ProjetoPOO_15.Code.DTO;

namespace ProjetoPOO_15.Ui
{
    public partial class Form4 : Form
    {
        DadosBLL da = new DadosBLL();
        DadosDTO dos = new DadosDTO();
        public Form4()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            dos.Ggf = txtGGF.Text;
            dos.G07 = txtG07.Text;
            dos.F05 = txtF05.Text;
            da.Insert(dos);
            txtGGF.Clear();
            txtG07.Clear();
            txtF05.Clear();
            dtgDados.DataSource = da.Read();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            dos.Id = int.Parse(txtID.Text);
            dos.Ggf = txtGGF.Text;
            dos.G07 = txtG07.Text;
            dos.F05 = txtF05.Text;
            da.Update(dos);
            txtID.Clear();
            txtGGF.Clear();
            txtG07.Clear();
            txtF05.Clear();
            dtgDados.DataSource = da.Read();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            dos.Id = int.Parse(txtID.Text);
            da.Delete(dos);
            txtID.Clear();
            txtGGF.Clear();
            txtG07.Clear();
            txtF05.Clear();
            dtgDados.DataSource = da.Read();
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            dtgDados.DataSource = da.Read();
        }

        private void dtgDados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dtgDados.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtGGF.Text = dtgDados.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtG07.Text = dtgDados.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtF05.Text = dtgDados.Rows[e.RowIndex].Cells[3].Value.ToString();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            dtgDados.DataSource = da.Read();
        }
    }
}
