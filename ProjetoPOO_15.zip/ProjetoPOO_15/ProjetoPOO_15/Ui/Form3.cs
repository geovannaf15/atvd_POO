﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjetoPOO_15.Code.BLL;
using ProjetoPOO_15.Code.DTO;

namespace ProjetoPOO_15.Ui
{
    public partial class Form3 : Form
    {
        UserBLL us = new UserBLL();
        UserDTO er = new UserDTO();
        public Form3()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            er.Name= txtNome.Text;
            er.Cell = txtTelefone.Text;
            er.Rua = txtRua.Text;
            er.Number = txtNumero.Text;
            er.Bairro = txtBairro.Text;
            er.City = txtCidade.Text;
            er.State = txtEstado.Text;
            er.Country = txtPais.Text;
            er.Cpf = txtCPF.Text;
            er.Rg = txtRG.Text;
            er.Birty= dtDataNascimento.Text;
            er.Email = txtEmail.Text;
            er.Password = txtSenha.Text;
            us.Insert(er);
            txtNome.Clear();
            txtTelefone.Clear();
            txtRua.Clear();
            txtNumero.Clear();
            txtBairro.Clear();
            txtCidade.Clear();
            txtEstado.Clear();
            txtPais.Clear();
            txtCPF.Clear();
            txtRG.Clear();
            txtEmail.Clear();
            txtSenha.Clear();

            dtgUsuarios.DataSource = us.Read();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            er.Id = int.Parse(txtId.Text);
            er.Name = txtNome.Text;
            er.Cell = txtTelefone.Text;
            er.Rua = txtRua.Text;
            er.Number = txtNumero.Text;
            er.Bairro = txtBairro.Text;
            er.City = txtCidade.Text;
            er.State = txtEstado.Text;
            er.Country = txtPais.Text;
            er.Cpf = txtCPF.Text;
            er.Rg = txtRG.Text;
            er.Birty = dtDataNascimento.Text;
            er.Email = txtEmail.Text;
            er.Password = txtSenha.Text;
            us.Update(er);
            txtId.Clear();
            txtNome.Clear();
            txtTelefone.Clear();
            txtRua.Clear();
            txtNumero.Clear();
            txtBairro.Clear();
            txtCidade.Clear();
            txtEstado.Clear();
            txtPais.Clear();
            txtCPF.Clear();
            txtRG.Clear();
            txtEmail.Clear();
            txtSenha.Clear();

            dtgUsuarios.DataSource = us.Read();
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            dtgUsuarios.DataSource = us.Read();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            er.Id = int.Parse(txtId.Text);
            us.Delete(er);
            dtgUsuarios.DataSource = us.Read();
        }

        private void dtgUsuarios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtId.Text = dtgUsuarios.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNome.Text = dtgUsuarios.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtTelefone.Text = dtgUsuarios.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtRua.Text = dtgUsuarios.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtNumero.Text = dtgUsuarios.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtBairro.Text = dtgUsuarios.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtCidade.Text = dtgUsuarios.Rows[e.RowIndex].Cells[6].Value.ToString();
            txtEstado.Text = dtgUsuarios.Rows[e.RowIndex].Cells[7].Value.ToString();
            txtPais.Text = dtgUsuarios.Rows[e.RowIndex].Cells[8].Value.ToString();
            txtCPF.Text = dtgUsuarios.Rows[e.RowIndex].Cells[9].Value.ToString();
            txtRG.Text = dtgUsuarios.Rows[e.RowIndex].Cells[10].Value.ToString();
            txtEmail.Text = dtgUsuarios.Rows[e.RowIndex].Cells[12].Value.ToString();
            txtSenha.Text = dtgUsuarios.Rows[e.RowIndex].Cells[13].Value.ToString();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dtgUsuarios.DataSource = us.Read();
        }
    }
}
