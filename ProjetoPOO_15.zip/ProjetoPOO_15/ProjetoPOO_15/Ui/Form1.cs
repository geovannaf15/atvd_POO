﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjetoPOO_15.Code.BLL;
using ProjetoPOO_15.Code.DTO;

namespace ProjetoPOO_15.Ui
{
    public partial class Form1 : Form
    {
        UserBLL logBLL = new UserBLL();
        UserDTO logDTO = new UserDTO();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            logDTO.Email = txtEmail.Text;
            logDTO.Cpf = txtCpf.Text;
            logDTO.Password = txtSenha.Text;

            if (logBLL.Login(logDTO) == true)
            {
                Form2 form = new Form2();
                form.ShowDialog();
            }
            else
            {
                MessageBox.Show("Algum dos campos está incorreto");
            }
        }
    }
}
